# Agente DOU - palavras-chave parametrizaveis

Monitora o Diario Oficial da Uniao (secao FIXA, data = dia atual) e filtra
materias por uma lista de palavras-chave EDITAVEL na propria interface.

## Rodar
    pip install -r requirements.txt
    python app.py
    # abra http://localhost:8000

## Formulario de palavras-chave
Na interface ha um campo onde voce adiciona/remove termos (chips) e clica em
"Salvar palavras-chave". O backend persiste em agents_db.json e o agente passa
a usar a nova lista imediatamente (inclusive em execucoes agendadas).

API: PUT /api/agents/<id>/keywords  body: {"keywords": ["a","b",...]}

## Padrao inicial
geoprocessamento, mapeamento, plataforma, sensoriamento, imageamento, sistemas
